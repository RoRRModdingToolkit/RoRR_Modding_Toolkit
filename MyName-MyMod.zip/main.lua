-- MyMod

local envy = mods["MGReturns-ENVY"]
envy.auto()
mods["RoRRModdingToolkit-RoRR_Modding_Toolkit"].auto()

PATH = _ENV["!plugins_mod_folder_path"]



-- ========== Main ==========

local function initialize()
    -- Initialization of content goes here
    -- https://github.com/RoRRModdingToolkit/RoRR_Modding_Toolkit/wiki/Initialize
    
end
Initialize(initialize)

-- ** Uncomment the two lines below to re-call initialize() on hotload **
-- if hotload then initialize() end
-- hotload = true